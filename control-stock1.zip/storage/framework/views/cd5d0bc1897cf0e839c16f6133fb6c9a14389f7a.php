

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

        </div>
    <?php endif; ?>
    
    <h4>Administracion de Datos de Proveedores</h4>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proveedor')): ?>
    <a href="<?php echo e(url('/proveedor/create')); ?>" class="btn btn-success btn-sm" title="Agregar proveedor">
        <i class="fa fa-plus" aria-hidden="true"></i> Agregar
    </a>
    <?php endif; ?>
    <form method="GET" action="<?php echo e(url('/proveedor')); ?>" accept-charset="UTF-8" class="form-inline my-2 my-lg-0 float-right" role="search">
        <span style="margin-right: 1.2em;">
       
        </span>
        <span class="input-group-append"  style="float:right">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Buscar..." value="<?php echo e(isset($search)?$search:''); ?>">
                
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                
            </div>
        </span>
    </form>

    <br/>
    <br/>
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>CUIT</th>
                    <th>Nombre Fantasia</th>
                    <th>Email</th>
                    <th>Celular</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->cuit); ?></td>
                    <td><?php echo e($item->nombre_fantasia); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->celular); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proveedor')): ?>
                        <a href="<?php echo e(url('proveedor/'.$item->id.'/edit')); ?>" title="Editar registro"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button></a>

                        <form method="POST" action="<?php echo e(url('/proveedor' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Borrar registro" onclick="return Confirm('delete')"><i class="fa fa-trash-o" aria-hidden="true"></i> Borrar</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($proveedores->appends(["search"=>isset($search)?$search:''])); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/proveedor/index.blade.php ENDPATH**/ ?>