

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

        </div>
    <?php endif; ?>
    
    <h4>Administracion de Ventas+</h4>
    <a href="<?php echo e(url('venta/create')); ?>" class="btn btn-success btn-sm" title="Nuevo Comprobante">
        <i class="fa fa-plus" aria-hidden="true"></i> Exportar
    </a>
    <form class="row g-3" action="<?php echo e(url('ventasPorProductos')); ?>" method="post" id="filtrosPersonales" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    
                    <label for="filtro" class="form-label">Filtros</label>
                        <div class="input-group">
                            <div class="row">
                                <div class="col-xs-3">
                                    <input id="fecha_desde" name="fecha_desde" type="date" class="form-control rounded" placeholder="Fecha desde" aria-label="Search" aria-describedby="search-addon"  value="<?php echo e(isset($filtro_fecha_vto)?$filtro_fecha_vto:''); ?>"/>
                                </div>
                                <div class="col-xs-3">
                                    <input id="fecha_hasta" name="fecha_hasta" type="date" class="form-control rounded" placeholder="Fecha hasta" aria-label="Search" aria-describedby="search-addon"  value="<?php echo e(isset($filtro_fecha_vto)?$filtro_fecha_vto:''); ?>"/>
                                </div>
                                <div class="col-xs-3">
                                    <button type="submit" class="btn btn-outline-primary">Buscar</button>
                                </div>
                                <div class="col-lg-2">

                                </div>
                            </div>
                        </div>
                    </form>

    <br/>
    <br/>
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>Producto</th>
                    <th>Peso</th>
                    <th>Cantidad</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $ventasPorProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($item->mercaderia_id); ?></td>
                    <td><?php echo e($item->descripcion); ?></td>
                    <td>$ <?php echo e($item->peso); ?></td>
                    <td>$ <?php echo e($item->cantidad); ?></td>
                    <td>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($ventasPorProductos->links("pagination::bootstrap-4")); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reportes/ventasPorProductos.blade.php ENDPATH**/ ?>