

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

        </div>
    <?php endif; ?>
    
     <!-- general form elements disabled -->
            <div class="card card-primary" style="margin-top: 20px;">
              <div class="card-header">
                <h3 class="card-title">Caja</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <form class=""  action="<?php echo e(route('cajaDetalle.index')); ?>" method="GET" id="indexgasto" enctype="multipart/form-data">
                <input type="hidden" id="metodo" name="metodo" value="">
                <input type="hidden" id="caja_id" name="caja_id" value="<?php echo e(isset($caja_id)?$caja_id:''); ?>">
                  <div class="row">
                        <div class="col-sm-2">
                        <!-- text input -->
                        <div class="form-group">
                            <label for="fecha_desde" class="form-label">Fecha Desde</label>
                            <input type="date" class="form-control" id="fecha_desde" name="fecha_desde" value="<?php echo e(isset($fecha_desde)?$fecha_desde:date('Y-m-d')); ?>">
                        </div>
                        </div>
                        <div class="col-sm-2">
                        <div class="form-group">
                            <label for="fecha_hasta" class="form-label">Fecha Hasta</label>
                            <input type="date" class="form-control" id="fecha_hasta" name="fecha_hasta" value="<?php echo e(isset($fecha_hasta)?$fecha_hasta:date('Y-m-d')); ?>">
                        </div>
                        </div>
                        <div class="col-sm-2">
                        <div class="form-group">
                            <label for="importe_inicial" class="form-label">Importe inicial</label>
                            <input type="text" class="form-control" id="importe_inicial" name="importe_inicial" value="<?php echo e(isset($importe_inicial)?$importe_inicial:''); ?>">
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                        <div class="card-footer">
                        <input type="button" class="btn btn-primary hacer_caja" tabindex="5" value="Hacer Caja"></a>
                        <input type="button" class="btn btn-primary guardar" tabindex="5" value="Guardar Caja"></a>
                            <a href="<?php echo e(url('/caja')); ?>" class="btn btn-secondary" tabindex="5">Volver</a>
                        </div>
                        </div>
                    </div>
                  <!-- input states -->
              </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- general form elements disabled -->

    VENTAS
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>Operacion</th>
                    <th>Concepto</th>
                    <th>Codigo</th>
                    <th>Monto</th>
                    <th>Cantidad</th>
                    <th>Sub-Total</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <div style="display:none"><?php echo e($subtotal_ventas = 0); ?></div>
            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="display:none"><?php echo e($subtotal_ventas += $item->monto * $item->cantidad); ?></div>
                <div style="display:none"><?php echo e($subtotal = $item->monto * $item->cantidad); ?></div>
                <tr>
                    <td><?php echo e($item->venta_detalle_id); ?></td>
                    <td>INGRESO</td>
                    <td><?php echo e($item->descripcion); ?></td>
                    <td><?php echo e($item->codigo); ?></td>
                    <td><?php echo e(number_format(floatVal($item->monto),2,',','.')); ?></td>
                    <td><?php echo e($item->cantidad); ?></td>
                    <td><?php echo e(number_format($subtotal,2,',','.')); ?></td>
                    <td><?php echo e($item->fecha); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($ventas->links("pagination::bootstrap-4")); ?>

    </div>

    COMPRAS
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>Operacion</th>
                    <th>Concepto</th>
                    <th>Codigo</th>
                    <th>Monto</th>
                    <th>Cantidad</th>
                    <th>Sub-Total</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <div style="display:none"><?php echo e($subtotal_compras = 0); ?></div>                
            <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display:none"><?php echo e($subtotal_compras += $item->monto * $item->cantidad); ?></div>
            <div style="display:none"><?php echo e($subtotal = $item->monto * $item->cantidad); ?></div>
                <tr>
                    <td><?php echo e($item->compra_detalle_id); ?></td>
                    <td>EGRESO</td>
                    <td><?php echo e($item->descripcion); ?></td>
                    <td><?php echo e($item->codigo); ?></td>
                    <td><?php echo e(number_format($item->monto,2,',','.')); ?></td>
                    <td><?php echo e($item->cantidad); ?></td>
                    <td><?php echo e(number_format($subtotal,2,',','.')); ?></td>
                    <td><?php echo e($item->fecha); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($compras->links("pagination::bootstrap-4")); ?>

    </div>

    GASTOS
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>Operacion</th>
                    <th>Concepto</th>
                    <th>Monto</th>
                    <th>Comentarios</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <div style="display:none"><?php echo e($subtotal_gastos = 0); ?></div>
            <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display:none"><?php echo e($subtotal_gastos += $item->monto); ?></div>
                <tr>
                    <td><?php echo e($item->gasto_id); ?></td>
                    <td>EGRESO</td>
                    <td><?php echo e($item->descripcion); ?></td>
                    <td><?php echo e(number_format($item->monto,2,',','.' )); ?></td>
                    <td><?php echo e($item->comentarios); ?></td>
                    <td><?php echo e($item->fecha); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($compras->links("pagination::bootstrap-4")); ?>


        RESUMEN
        <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>INGRESOS</th>
                    <th>EGRESOS</th>
                    <th>RESULTADO</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display:none"><?php echo e($subtotal_gastos += $item->monto); ?></div>
            <div style="display:none"><?php echo e($subtotal_egresos = $subtotal_compras + $subtotal_gastos); ?></div>
            <div style="display:none"><?php echo e($total = $subtotal_compras - ($subtotal_compras + $subtotal_gastos)); ?></div>
                <tr>
                    <td style="color:green"><?php echo e(number_format($subtotal_ventas,2,',','.')); ?></td>
                    <td style="color: red;"><?php echo e(number_format($subtotal_egresos,2,',','.')); ?></td>
                    <td style="color:blue"><?php echo e(number_format($total,2,',','.')); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php $__env->stopSection(); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('vendor/Jquery-ui/jquery-ui.min.css')); ?>">
<script src="<?php echo e(asset('vendor/Jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type='text/javascript'>
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){

        $(".hacer_caja").click(function (e) {
                $("#metodo").val("FILTRO");
                $("#indexgasto").submit();
            });

        $(".guardar").click(function (e) {//alert($('meta[name="csrf-token"]').attr('content'));
                $("#metodo").val("GUARDAR");
                $("#indexgasto").submit();
            });
    });
</script>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/cajaDetalle/index.blade.php ENDPATH**/ ?>