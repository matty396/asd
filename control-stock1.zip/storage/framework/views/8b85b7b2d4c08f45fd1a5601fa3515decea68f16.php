

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

        </div>
    <?php endif; ?>
    
    <h4>Administracion de Ventas+</h4>
    <a href="<?php echo e(url('venta/create')); ?>" class="btn btn-success btn-sm" title="Nuevo Comprobante">
        <i class="fa fa-plus" aria-hidden="true"></i> Nueva Venta
    </a>
    <form method="GET" action="<?php echo e(url('/venta')); ?>" accept-charset="UTF-8" class="form-inline my-2 my-lg-0 float-right" role="search">
        <span style="margin-right: 1.2em;">
       
        </span>
        <span class="input-group-append"  style="float:right">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Buscar..." value="<?php echo e(request('search')); ?>">
                
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                
            </div>
        </span>
    </form>

    <br/>
    <br/>
    <div class="table-responsive">
        <table class="table table-light table-hover">
            <thead class="thead-light">
                <tr>
                    <th>Id</th>
                    <th>Cliente</th>
                    <th>Total</th>
                    <th>Pago</th>
                    <th>Saldo</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($item->id); ?></td>
                    <td><?php echo e($item->cliente); ?></td>
                    <td>$ <?php echo e(number_format($item->total,2,",",".")); ?></td>
                    <td>$ <?php echo e(number_format($item->pago),2,",","."); ?></td>
                    <td>$ <?php echo e(number_format($item->total - $item->pago,2,",",".")); ?></td>
                    <td><?php echo e($item->fecha); ?></td>
                    <td>
                        <a href="<?php echo e(url('venta/'.$item->id.'/edit')); ?>" title="Editar registro"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button></a>
                        <form method="POST" action="<?php echo e(url('/venta' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Borrar registro" onclick="return Confirm('delete')"><i class="fa fa-trash-o" aria-hidden="true"></i> Borrar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($ventas->links("pagination::bootstrap-4")); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/venta/index.blade.php ENDPATH**/ ?>